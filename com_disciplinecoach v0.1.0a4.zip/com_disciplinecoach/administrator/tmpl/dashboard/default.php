<?php
/**
 * Dashboard template voor DisciplineCoach component.
 *
 * @var  Joomla\CMS\MVC\View\HtmlView  $this
 */

defined('_JEXEC') or die;
?>
<div class="container-fluid">
    <h1 class="page-title">
        <span class="icon-list-2" aria-hidden="true"></span>
        DisciplineCoach
    </h1>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <p>Welkom bij het DisciplineCoach component.</p>
                    <p>Versie 0.1.0 — component is succesvol geladen.</p>
                </div>
            </div>
        </div>
    </div>
</div>
