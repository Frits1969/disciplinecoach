<?php
/**
 * ========================================================================
 * DisciplineCoach
 * Joomla 6 Component
 * ========================================================================
 *
 * File        : provider.php
 * Purpose     : Registers the component services within Joomla's
 *               dependency injection container.
 *
 * Author      : Frits van Leeuwen
 * Created     : 2026-10-28
 * Modified    : 2026-10-29
 * Version     : 0.1.0
 *
 * Copyright   : Copyright (C) 2026 Frits van Leeuwen
 * License     : GNU General Public License version 2 or later
 *
 * ========================================================================
 */

defined('_JEXEC') or die;

use Joomla\CMS\Extension\ComponentInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

use Fvl\Component\DisciplineCoach\Administrator\Extension\DisciplinecoachComponent;

return new class implements ServiceProviderInterface
{
    public function register(Container $container): void
    {
        $container->set(
            ComponentInterface::class,
            function (Container $container) {
                return new DisciplinecoachComponent($container);
            }
        );
    }
};
